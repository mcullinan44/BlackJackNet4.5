﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Blackjack.Core;

namespace BlackJackWinform
{
    public partial class HandControl : UserControl
    {
        public readonly IHand Hand;
        protected readonly List<PictureBox> pictureBoxList;
        protected readonly GameController Controller;

        public HandControl(IHand hand, GameController controller)
        {
            InitializeComponent();
            this.Hand = hand;
            this.pictureBoxList = new List<PictureBox>();
            this.Controller = controller;
            hand.onBust += hand_onBust;
            hand.onBlackjack += hand_onBlackjack;
            hand.onWinHand += hand_onWinHand;
            hand.onLoseHand += hand_onLoseHand;
            hand.onPushHand += hand_onPushHand;
        }

        public void AddCard(Card card, bool isFaceUp)
        {
            var pictureBox = new PictureBox();
            pictureBox.Height = 106;
            pictureBox.Width = 72;
            Point p = new Point();
            if (pictureBoxList.Count > 0)
            {
                p.X = pictureBoxList[pictureBoxList.Count - 1].Location.X + 15;
                p.Y = pictureBoxList[pictureBoxList.Count - 1].Location.Y + 15;
            }
            pictureBox.Location = p;
            pictureBox.Tag = card;
            pictureBoxList.Add(pictureBox);
            pnlHand.Controls.Add(pictureBox);
            pictureBox.BringToFront();
            var image = isFaceUp ? ImageHelper.GetFaceImageForCard(card) : ImageHelper.GetBackImage();
            pictureBox.Image = image;
        }

        public void AddCard(Card card)
        {
            AddCard(card, true);
        }

        public void ShowAllCards()
        {
            this.pictureBoxList.Clear();
            pnlHand.Controls.Clear();
            foreach (var card in Hand.Cards)
            {
                AddCard(card, true);
            }
        }

        public void EndGame()
        {
            this.pictureBoxList.Clear();
            pnlHand.Controls.Clear();
        }

        public bool IsActive
        {
            get { return this.lblActive.Visible; }
            set
            {
                this.lblActive.Visible = value;
            }
        }

        void hand_onBlackjack(object sender, OnCardReceivedEventArgs args)
        {
            lblOutcome.Text = "Blackjack!";
        }

        void hand_onBust(object sender, OnCardReceivedEventArgs args)
        {
            this.IsActive = false;
            lblOutcome.Text = "Bust";
            lblOutcome.Visible = true;
        }

        void hand_onPushHand(Hand hand)
        {
            lblOutcome.Text = "Push";
        }

        void hand_onLoseHand(Hand hand)
        {
            lblOutcome.Text = "Lose with " + hand.CurrentScore;
        }

        void hand_onWinHand(Hand hand)
        {
            lblOutcome.Text = "Win with " + hand.CurrentScore;
        }
    }
}
