﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Blackjack.Core;

namespace BlackJackWinform
{
    public partial class NewSessionDialog : Form
    {
        public NewSessionDialog()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //controller.MinimumBet = this.Minimum;
            //controller.NumberOfDecks = this.NumberOfDecks;
            //controller.PlayerbankRoll = this.Bankroll;
            
            this.Close();
        }

        public int Minimum
        {
            get { return Convert.ToInt32(nmrcMinimum.Value); }
        }

        public int Bankroll
        {
            get { return Convert.ToInt32(nmrcBankroll.Value) ; }
        }

        public int NumberOfDecks
        {
            get { return Convert.ToInt32(nmrcNumberOfDecks.Value); }
        }

        private void nmrcBankroll_ValueChanged(object sender, EventArgs e)
        {
            if (nmrcMinimum.Value > nmrcBankroll.Value)
                nmrcBankroll.Value = nmrcMinimum.Value;

        }

        private void nmrcMinimum_ValueChanged(object sender, EventArgs e)
        {
            nmrcBankroll_ValueChanged(sender, e);
        }

        private void nmrcNumberOfDecks_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
