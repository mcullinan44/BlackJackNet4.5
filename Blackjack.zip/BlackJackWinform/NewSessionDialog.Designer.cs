﻿namespace BlackJackWinform
{
    partial class NewSessionDialog
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.nmrcMinimum = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.nmrcNumberOfDecks = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.nmrcBankroll = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.nmrcMinimum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmrcNumberOfDecks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmrcBankroll)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(103, 114);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Number of Decks:";
            // 
            // nmrcMinimum
            // 
            this.nmrcMinimum.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nmrcMinimum.Location = new System.Drawing.Point(103, 46);
            this.nmrcMinimum.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nmrcMinimum.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nmrcMinimum.Name = "nmrcMinimum";
            this.nmrcMinimum.Size = new System.Drawing.Size(46, 20);
            this.nmrcMinimum.TabIndex = 1;
            this.nmrcMinimum.ThousandsSeparator = true;
            this.nmrcMinimum.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nmrcMinimum.ValueChanged += new System.EventHandler(this.nmrcMinimum_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Minimum:";
            // 
            // nmrcNumberOfDecks
            // 
            this.nmrcNumberOfDecks.Location = new System.Drawing.Point(103, 15);
            this.nmrcNumberOfDecks.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nmrcNumberOfDecks.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmrcNumberOfDecks.Name = "nmrcNumberOfDecks";
            this.nmrcNumberOfDecks.Size = new System.Drawing.Size(46, 20);
            this.nmrcNumberOfDecks.TabIndex = 0;
            this.nmrcNumberOfDecks.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmrcNumberOfDecks.ValueChanged += new System.EventHandler(this.nmrcNumberOfDecks_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Bankroll:";
            // 
            // nmrcBankroll
            // 
            this.nmrcBankroll.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nmrcBankroll.Location = new System.Drawing.Point(103, 78);
            this.nmrcBankroll.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nmrcBankroll.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nmrcBankroll.Name = "nmrcBankroll";
            this.nmrcBankroll.Size = new System.Drawing.Size(120, 20);
            this.nmrcBankroll.TabIndex = 2;
            this.nmrcBankroll.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nmrcBankroll.ValueChanged += new System.EventHandler(this.nmrcBankroll_ValueChanged);
            // 
            // NewSessionDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 158);
            this.Controls.Add(this.nmrcBankroll);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.nmrcNumberOfDecks);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nmrcMinimum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "NewSessionDialog";
            this.Text = "Game Options";
            ((System.ComponentModel.ISupportInitialize)(this.nmrcMinimum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmrcNumberOfDecks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmrcBankroll)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nmrcMinimum;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nmrcNumberOfDecks;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nmrcBankroll;
    }
}
