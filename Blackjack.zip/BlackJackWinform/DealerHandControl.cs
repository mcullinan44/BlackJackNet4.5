﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Blackjack.Core;

namespace BlackJackWinform
{
    public partial class DealerHandControl : HandControl
    {
        public DealerHandControl(IHand hand, GameController controller): base(hand, controller)
        {
            hand.onCardReceived += dealer_onCardReceived;
            lblOutcome.Text = string.Empty;
            lblOutcome.Visible = false;
        }

        void hand_onPushHand(Hand hand)
        {
            lblOutcome.Text = "Push";
        }

        void hand_onLoseHand(Hand hand)
        {
            lblOutcome.Text = hand.CurrentScore.ToString();
            lblOutcome.Visible = true;
        }

        void hand_onWinHand(Hand hand)
        {
            lblOutcome.Text = hand.CurrentScore.ToString();
            lblOutcome.Visible = true;
        }

        void dealer_onBust(object sender, OnCardReceivedEventArgs args)
        {
            ((PlayerHand)Controller.PlayerOne.ActiveHand).WinHand();
            lblOutcome.Text = "Dealer busts with " + args.Hand.CurrentScore;
            lblOutcome.Visible = true;
        }

        void dealer_onBlackjack(object sender, OnCardReceivedEventArgs args)
        {
            lblOutcome.Text = "Dealer Blackjack";
            lblOutcome.Visible = true;
        }

        void dealer_onCardReceived(object sender, OnCardReceivedEventArgs args)
        {
            try
            {
                if (args.Hand.CardCount == 2)
                {
                    this.AddCard(args.Card, false);
                }
                else
                {
                    this.AddCard(args.Card);
                }
            }
            catch (Exception ex)
            {
                var msg = ex.Message;
            }
        }
    }
}
