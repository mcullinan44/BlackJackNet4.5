﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using Blackjack.Core;

namespace BlackJackWinform
{
    public partial class BlackJackForm : Form
    {
        private List<PlayerHandControl> playerHandControlList = new List<PlayerHandControl>();
        private DealerHandControl dealerHandControl;
        private readonly GameController controller;
        //Bug occurs when splitting into a blackjack
        public BlackJackForm()
        {
            InitializeComponent();
            this.controller = new GameController();
            controller.OnBankrollChange += Instance_OnBankrollChange;
            controller.OnShowAllCards += Instance_OnShowAllCards;
            controller.OnGameEnd += Instance_OnGameEnd;
            controller.MinimumBet = Defaults.MinimumBet;
            controller.NumberOfDecks = Defaults.NumberOfDecks;
            controller.PlayerbankRoll = Defaults.Bankroll;
            controller.StartNewSession(1, 10);
            controller.ShuffleAll();

            tbBet.Text = controller.MinimumBet.ToString("c0");
        }

        #region User Events

        private void btnHit_Click(object sender, EventArgs e)
        {
            controller.Hit();
        }

        private void btnStand_Click(object sender, EventArgs e)
        {
            playerHandControlList.Find(i => i.Hand == controller.PlayerOne.ActiveHand).IsActive = false;
            controller.Stand();
            //var newHand = playerHandControlList.Find(i => i.Hand == controller.PlayerOne.ActiveHand);
            //if(newHand != null)
            //{
            //    newHand.IsActive = true;
            //}
        }

        private void btnSplit_Click(object sender, EventArgs e)
        {
            var newhand = (PlayerHand)controller.CreateNewHandForSplit();
            var newHandControl = new PlayerHandControl(newhand, controller);
            playerHandControlList.Add(newHandControl);
            layout.Controls.Add(newHandControl);
            var splittingHandControl = playerHandControlList.Find(i => i.Hand == controller.PlayerOne.ActiveHand);
            splittingHandControl.Split(newhand);
        }

        private void btnDoubleDown_Click(object sender, EventArgs e)
        {
            playerHandControlList.Find(i => i.Hand == controller.PlayerOne.ActiveHand).IsActive = false;
            controller.DoubleDown();
            var newHand = playerHandControlList.Find(i => i.Hand == controller.PlayerOne.ActiveHand);
            if(newHand != null)
            {
                newHand.IsActive = true;
            }
        }

        private void newSessionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewSessionDialog dialog = new NewSessionDialog();
            dialog.ShowDialog();
            controller.MinimumBet = dialog.Minimum;
            controller.NumberOfDecks = dialog.NumberOfDecks;
            controller.PlayerbankRoll = dialog.Bankroll;
            btnBet.Enabled = true;
            tbBet.Enabled = true;
        }

        private void btnBet_Click(object sender, EventArgs e)
        {
            Console.WriteLine("--------------------------------------");
            btnBet.Enabled = false;
            btnHit.Enabled = true;
            btnStand.Enabled = true;
            btnDoubleDown.Enabled = true;
            if (controller.Shoe.UndealtCards < 22)
                controller.ShuffleAll();
            controller.StartNewHand();
            controller.Dealer.ActiveHand.onBust += Instance_OnGameEnd;
            controller.Dealer.ActiveHand.onBust += Instance_OnShowAllCards;
            controller.Dealer.ActiveHand.onBlackjack += Instance_OnGameEnd;
            controller.Dealer.ActiveHand.onBlackjack += Instance_OnShowAllCards;
            dealerLayoutPanel.Controls.Clear();
            dealerHandControl = new DealerHandControl(controller.Dealer.ActiveHand, controller);
            dealerLayoutPanel.Controls.Add(dealerHandControl);
            foreach(var control in playerHandControlList)
            {
                control.EndGame();
            }
            layout.Controls.Clear();
            var playerHandControl = new PlayerHandControl(controller.PlayerOne.ActiveHand, int.Parse(tbBet.Text), controller);
            playerHandControlList.Add(playerHandControl);
            layout.Controls.Add(playerHandControl);
            controller.Deal();
        }

        void ActiveHand_onBust(object sender, OnCardReceivedEventArgs args)
        {
            var newHand = playerHandControlList.Find(i => i.Hand == controller.PlayerOne.ActiveHand);
            if (newHand != null)
            {
                newHand.IsActive = true;
            }
        }

        //void ActiveHand_onCardReceived(object sender, OnCardReceivedEventArgs args)
        //{
        //    if (args.Hand.Cards.Count == 2)
        //    {
        //        if (args.Hand.Cards[0].CardType == args.Hand.Cards[1].CardType
        //            && args.Hand.Cards[0].Value == args.Hand.Cards[1].Value)
        //        {

        //            btnSplit.Enabled = true;
        //        }
        //        btnDoubleDown.Enabled = true;
        //    }
        //    else
        //    {
        //        btnDoubleDown.Enabled = false;
        //        btnSplit.Enabled = false;
        //    }
        //}

        //void controller_OnActiveHandChanged(object sender, EventArgs e)
        //{
        //    if (controller.PlayerOne.ActiveHand.Cards.Count == 2)
        //    {
        //        if (controller.PlayerOne.ActiveHand.Cards[0].CardType == controller.PlayerOne.ActiveHand.Cards[1].CardType
        //            && controller.PlayerOne.ActiveHand.Cards[0].Value == controller.PlayerOne.ActiveHand.Cards[1].Value)
        //        {
        //            btnSplit.Enabled = true;
        //        }

        //        btnDoubleDown.Enabled = true;
        //    }
        //    else
        //    {
        //        btnDoubleDown.Enabled = false;
        //        btnSplit.Enabled = false;
        //    }
        //    var activeHand = (PlayerHand)controller.PlayerOne.ActiveHand;
        //    btnDoubleDown.Enabled = true;
        //    var activeControl = playerHandControlList.Find(i => i.Hand.IsActive);
        //    activeControl.IsActive = true;
        //}

        #endregion

        #region Game Events

        void Instance_OnGameEnd(object sender, EventArgs e)
        {
            tbBet.Enabled = true;
            btnBet.Enabled = true;
            btnDoubleDown.Enabled = false;
            btnHit.Enabled = false;
            btnStand.Enabled = false;
            btnSplit.Enabled = false;
        }

        void Instance_OnShowAllCards(object sender, EventArgs e)
        {
            dealerHandControl.ShowAllCards();
        }

        void Instance_OnBankrollChange(object sender, EventArgs e)
        {
            lblBankroll.Text = controller.PlayerbankRoll.ToString("c0");
        }

        #endregion
    }
}
