﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Blackjack.Core;

namespace BlackJackWinform
{
    public partial class PlayerHandControl : HandControl
    {
        public PlayerHandControl(IHand hand, GameController controller) : base (hand, controller)
        {
            InitializeComponent();
            controller.OnActiveHandChanged += controller_OnActiveHandChanged;
            hand.CurrentBet.onBetChanged += CurrentBet_onBetChanged;
            lblBet.Visible = true;
        }

        public PlayerHandControl(IHand hand, int bet, GameController controller)
            : this(hand, controller)
        {
            InitializeComponent();
            controller.OnActiveHandChanged += controller_OnActiveHandChanged;
            hand.CurrentBet.onBetChanged += CurrentBet_onBetChanged;
            hand.onCardReceived +=hand_onCardReceived;
            lblBet.Visible = true;
            lblBet.Text = bet.ToString("c0");
            hand.CurrentBet.Amount = bet;
        }

        void controller_OnActiveHandChanged(object sender, EventArgs e)
        {
             lblActive.Visible = this.IsActive;
        }
   
        public void Split(PlayerHand newHand)
        {
            //Take card from old hand
            newHand.ReceiveCard(this.Hand.Cards[1], true);
            this.pictureBoxList.Remove(pictureBoxList.Find(i => i.Tag == this.Hand.Cards[1]));
            this.Hand.Cards.RemoveAt(1);
            pnlHand.Controls.RemoveAt(0);
            this.IsActive = false;

            //"Old" hand gets new card
            this.Hand.ReceiveCard(Controller.Shoe.NextCard, true);
            //New hand gets second card
            newHand.ReceiveCard(Controller.Shoe.NextCard, true);
            Controller.ActivateNextHand();
        }

        void hand_onBlackjack(object sender, OnCardReceivedEventArgs args)
        {
            lblWinning.Text = "+ " + this.Hand.CurrentBet.Amount.ToString("c0");
        }

        void hand_onBust(object sender, OnCardReceivedEventArgs args)
        {
            lblWinning.Text = "-" + args.Hand.CurrentBet.Amount.ToString("c0");
            lblWinning.Visible = lblOutcome.Visible = true;
        }

        void hand_onPushHand(Hand hand)
        {
            lblWinning.Text = "$0";
            lblWinning.Visible = lblOutcome.Visible = true;
        }

        void hand_onLoseHand(Hand hand)
        {
            lblWinning.Text = "- " + hand.CurrentBet.Amount.ToString("c0");
            lblWinning.Visible = lblOutcome.Visible = true;
        }

        void hand_onWinHand(Hand hand)
        {
            lblWinning.Text = "+ " + hand.CurrentBet.Amount.ToString("c0");
            lblWinning.Visible = lblOutcome.Visible = true;
        }

        void hand_onCardReceived(object sender, OnCardReceivedEventArgs args)
        {
            AddCard(args.Card);
            if (args.Hand.Cards.Count == 2)
            {
                if (args.Hand.Cards[0].CardType == args.Hand.Cards[1].CardType
                    && args.Hand.Cards[0].Value == args.Hand.Cards[1].Value)
                {

                 //  this.parentForm.btnSplit.Enabled = true;
                }
               // this.parentForm.btnDoubleDown.Enabled = true;
            }
            else
            {
               // this.parentForm.btnDoubleDown.Enabled = false;
               // this.parentForm.btnSplit.Enabled = false;
            }
        }

        void CurrentBet_onBetChanged(object sender, OnBetChangedEventArgs args)
        {
            lblBet.Text = args.NewBet.Amount.ToString("c0");
        }
    }
}
