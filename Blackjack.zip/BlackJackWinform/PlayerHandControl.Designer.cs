﻿namespace BlackJackWinform
{
    partial class PlayerHandControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblActive = new System.Windows.Forms.Label();
            this.pnlMoney = new System.Windows.Forms.Panel();
            this.lblOutcome = new System.Windows.Forms.Label();
            this.lblWinning = new System.Windows.Forms.Label();
            this.lblBet = new System.Windows.Forms.Label();
            this.pnlHand = new System.Windows.Forms.Panel();
            this.pnlMoney.SuspendLayout();
            this.pnlHand.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblActive
            // 
            this.lblActive.AutoSize = true;
            this.lblActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActive.ForeColor = System.Drawing.Color.Yellow;
            this.lblActive.Location = new System.Drawing.Point(78, -4);
            this.lblActive.Name = "lblActive";
            this.lblActive.Size = new System.Drawing.Size(25, 31);
            this.lblActive.TabIndex = 0;
            this.lblActive.Text = "*";
            this.lblActive.Visible = false;
            // 
            // pnlMoney
            // 
            this.pnlMoney.Controls.Add(this.lblOutcome);
            this.pnlMoney.Controls.Add(this.lblWinning);
            this.pnlMoney.Controls.Add(this.lblBet);
            this.pnlMoney.Location = new System.Drawing.Point(0, 0);
            this.pnlMoney.Name = "pnlMoney";
            this.pnlMoney.Size = new System.Drawing.Size(132, 42);
            this.pnlMoney.TabIndex = 1;
            // 
            // lblOutcome
            // 
            this.lblOutcome.AutoSize = true;
            this.lblOutcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutcome.ForeColor = System.Drawing.Color.Yellow;
            this.lblOutcome.Location = new System.Drawing.Point(10, 19);
            this.lblOutcome.Name = "lblOutcome";
            this.lblOutcome.Size = new System.Drawing.Size(72, 17);
            this.lblOutcome.TabIndex = 2;
            this.lblOutcome.Text = "{outcome}";
            this.lblOutcome.Visible = false;
            // 
            // lblWinning
            // 
            this.lblWinning.AutoSize = true;
            this.lblWinning.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWinning.ForeColor = System.Drawing.Color.Yellow;
            this.lblWinning.Location = new System.Drawing.Point(41, 4);
            this.lblWinning.Name = "lblWinning";
            this.lblWinning.Size = new System.Drawing.Size(34, 17);
            this.lblWinning.TabIndex = 1;
            this.lblWinning.Text = "{$0}";
            this.lblWinning.Visible = false;
            // 
            // lblBet
            // 
            this.lblBet.AutoSize = true;
            this.lblBet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBet.ForeColor = System.Drawing.Color.Yellow;
            this.lblBet.Location = new System.Drawing.Point(10, 4);
            this.lblBet.Name = "lblBet";
            this.lblBet.Size = new System.Drawing.Size(34, 17);
            this.lblBet.TabIndex = 0;
            this.lblBet.Text = "{$0}";
            this.lblBet.Visible = false;
            // 
            // pnlHand
            // 
            this.pnlHand.Controls.Add(this.lblActive);
            this.pnlHand.Location = new System.Drawing.Point(0, 48);
            this.pnlHand.Name = "pnlHand";
            this.pnlHand.Size = new System.Drawing.Size(132, 203);
            this.pnlHand.TabIndex = 2;
            // 
            // PlayerHandControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlHand);
            this.Controls.Add(this.pnlMoney);
            this.Name = "PlayerHandControl";
            this.Size = new System.Drawing.Size(132, 254);
            this.pnlMoney.ResumeLayout(false);
            this.pnlMoney.PerformLayout();
            this.pnlHand.ResumeLayout(false);
            this.pnlHand.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblActive;
        private System.Windows.Forms.Panel pnlMoney;
        private System.Windows.Forms.Label lblBet;
        private System.Windows.Forms.Label lblWinning;
        protected System.Windows.Forms.Label lblOutcome;
        private System.Windows.Forms.Panel pnlHand;

    }
}
