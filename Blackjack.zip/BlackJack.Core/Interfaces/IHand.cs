﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack.Core
{
    public interface IHand
    {
        Bet CurrentBet { get; set; }

        void ReceiveCard(Card card, bool isDeal);

        bool IsFinalized { get; set; }

        bool IsBlackjack { get; set; }

        bool IsBust { get; set; }

        List<Card> Cards { get; }

        int CardCount { get;  }

        int CurrentScore { get;  }

        bool IsActive { get; set; }

        Result Result { get; set; }

        event OnCardReceived onCardReceived;

        event OnBlackjack onBlackjack;

        event OnBust onBust;

        event OnWinHand onWinHand;

        event OnLoseHand onLoseHand;

        event OnPushHand onPushHand;

    }
}
