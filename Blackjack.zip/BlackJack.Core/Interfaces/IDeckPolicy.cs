﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack.Core
{
    public interface IDeckPolicy
    {
        bool UseFirstJoker { get; set; }

        bool UseSecondJoker { get; set;  }

        bool AceIsHighOrLow { get; set; }

        void ProcessOptions(Deck deck);
    }
}
