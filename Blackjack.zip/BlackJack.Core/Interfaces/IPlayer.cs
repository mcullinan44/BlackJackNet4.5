﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack.Core
{
    public interface IPlayer
    {
        string Name { get; set; }

        List<IHand> CurrentHands { get; set;  }

        int Position { get; }

        IHand ActiveHand { get; }
    }
}
