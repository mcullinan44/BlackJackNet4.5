﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack.Core
{
    public sealed class Shoe
    {
        private readonly List<Deck> deckList;
        
        public Shoe(int numberOfDecks, IDeckPolicy options)
        {
            deckList = new List<Deck>(numberOfDecks);
            while (deckList.Count < numberOfDecks)
            {
                var deck = new Deck(options);
               
                deckList.Add(deck);
            }


        }

        public IList<Deck> DeckList
        {
            get
            { 
                return deckList;  
            }
        }

        public int UndealtCards
        {
            get
            {
                int undealtCards = 0;

                foreach(var deck in this.DeckList)
                {
                    undealtCards = +deck.CardList.FindAll(i => !i.IsDealt).Count;
                }
                return undealtCards;

            }

        }
      
        public Card SplitTester(Card prevCard)
        {
            Card topCard = null;
            bool isFound = false;


            foreach (var deck in deckList)
            {
                if (isFound)
                    break;
                foreach (var card in deck.CardList)
                {
                    if (!card.IsDealt && card.Index == prevCard.Index )
                    {
                        topCard = card;
                        topCard.IsDealt = true;
                        isFound = true;
                        break;
                    }
                }
            }

            if (topCard == null)
                throw new ArgumentNullException("the card is null", "the card is null");
            return topCard;
        }


        public Card NextCard
        {
            get
            {
                Card topCard = null;
                bool isFound = false;
           
           
                foreach (var deck in deckList)
                {
                    if (isFound)
                        break;
                    foreach (var card in deck.CardList)
                    {
                        if (!card.IsDealt)
                        {
                            topCard = card;
                            topCard.IsDealt = true;
                            isFound = true;
                            break;
                        }
                    }
                }

                if (topCard == null)
                    throw new ArgumentNullException("the card is null", "the card is null");
                return topCard;
            }
        }
    }
}
