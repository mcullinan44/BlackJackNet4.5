﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack.Core
{
    public sealed class Player : IPlayer
    {
        private List<IHand> currentHands;
        private readonly int position;

        public Player(int position)
        {
            currentHands = new List<IHand>();
            this.position = position;
        }

        public string Name { get; set; }

        public List<IHand> CurrentHands
        {
            get
            {
                return currentHands;
            }
            set
            {
                currentHands = value;
            }
        }

        public int Position { get { return position; } }

        public IHand ActiveHand
        {
            get { return this.CurrentHands.Find(i => i.IsActive); }
        }
    }
}
