﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Blackjack.Core;

namespace Blackjack.Core
{
    public class BlackjackDeckPolicy : IDeckPolicy
    {
        public BlackjackDeckPolicy(bool useFirstJoker, bool useSecondJoker, bool aceIsHighOrLow)
        {
            UseFirstJoker = useFirstJoker;
            UseSecondJoker = useSecondJoker;
            AceIsHighOrLow = aceIsHighOrLow;
        }
        
        
        public bool UseFirstJoker { get; set; }

        public bool UseSecondJoker { get; set; }

        public bool AceIsHighOrLow { get; set; }

        public void ProcessOptions(Deck deck)
        {
            if(UseFirstJoker)
            {

            }

            if(UseSecondJoker)
            {

            }

            if(AceIsHighOrLow)
            {

            }
        }
    }
}
