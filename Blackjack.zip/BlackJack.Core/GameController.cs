﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack.Core
{
    public sealed class GameController
    {
        public event EventHandler OnBankrollChange;
        public event EventHandler OnShowAllCards;
        public event EventHandler OnActiveHandChanged;
        public event EventHandler OnGameEnd;
        private readonly IList<IPlayer> playerlist;
        private readonly int minimumBet;

        private double bankroll = 0;

        public GameController()
        {
            this.playerlist = new List<IPlayer>();
        }

        #region Properties

        public Player PlayerOne
        {
            get { return (Player)this.PlayerList.First(i => i.Position == 1); }
        }

        public Dealer Dealer
        {
            get { return (Dealer)this.PlayerList.First(i => i.Position == 0); }
        }

        public IList<IPlayer> PlayerList
        {
            get { return playerlist; }
        }

        public int NumberOfDecks { get; set; }

        public int MinimumBet { get;  set;  }

        public Shoe Shoe
        {
            get;
            set;
        }

        public double PlayerbankRoll
        {
            get { return bankroll; }
            set
            {
                bankroll = value;
                OnBankrollChange(this, null);
            }
        }

        #endregion

        #region Methods

        public void ShuffleAll()
        {
            foreach (var deck in Shoe.DeckList)
            {
                deck.Shuffle();
            }
        }

        public void StartNewSession(int numberOfDecks, int minimumBet)
        {
            IDeckPolicy deckPolicy = new BlackjackDeckPolicy(false, false, true);
            this.Shoe = new Shoe(numberOfDecks, deckPolicy);
            IPlayer dealer = new Dealer();
            IPlayer player = new Player(1);
            playerlist.Add(player);
            playerlist.Add(dealer);
        }

        public void StartNewHand()
        {
            PlayerOne.CurrentHands.Clear();
            Dealer.CurrentHands.Clear();
            DealerHand dh = new DealerHand((Dealer)playerlist.First(i => i.Position == 0), this);
            dh.IsActive = true;
            PlayerHand ph = new PlayerHand((Player)playerlist.First(i => i.Position == 1), this);
            ph.IsActive = true;
        }

        public void Deal()
        {
            for (var i = 0; i < 2; i++)
            {
                foreach (var player in playerlist)
                {
                    foreach (var hand in player.CurrentHands)
                    {
                        //Add an overload here for testing...
                        var card = hand.Cards.Count == 1 && player.Position == 1 ? this.Shoe.SplitTester(hand.Cards[0]) : this.Shoe.NextCard ;
                     
                        //if (player.Position == 0)
                        //{
                        //    if (hand.Cards.Find(c => c.DealFaceUp) == null)
                        //    {
                        //        card.DealFaceUp = true;
                        //    }
                        //}
                        hand.ReceiveCard(card, true);
                    }
                }
            }
        }

        public IHand CreateNewHandForSplit()
        {
            var hand = PlayerOne.CurrentHands.Find(i => i.IsActive);
            var newHand = new PlayerHand(PlayerOne, this);
            Bet bet = new Bet(newHand, this) { ChipList = hand.CurrentBet.ChipList, Amount = hand.CurrentBet.Amount };
            newHand.CurrentBet = bet;

            return newHand;
        }

        public void Hit()
        {
            var card = Shoe.NextCard;
           PlayerOne.ActiveHand.ReceiveCard(card, false);
        }

        public void Stand()
        {
            PlayerOne.ActiveHand.IsFinalized = true;
            this.ActivateNextHand();
        }

        public void DoubleDown()
        {
            PlayerOne.ActiveHand.CurrentBet.Amount *= 2;
            PlayerOne.ActiveHand.ReceiveCard(Shoe.NextCard, false);
            PlayerOne.ActiveHand.IsFinalized = true;
            ActivateNextHand();
        }

        public void ActivateNextHand()
        {
            var currentHand = ((Player)PlayerOne).ActiveHand;
            var nextHand = PlayerOne.CurrentHands.FindLast(v => !v.IsFinalized && !v.IsActive);
            if (nextHand != null)
            {
                currentHand.IsActive = false;
                nextHand.IsActive = true;
                OnActiveHandChanged(this, null);
            }
            else if(PlayerOne.CurrentHands.Find(v => !v.IsBlackjack) != null 
                && PlayerOne.CurrentHands.Find(v => !v.IsBust) != null)
            {
                
                playForDealer();
                if(!Dealer.ActiveHand.IsBust)
                    calculateScore();
                OnGameEnd(this, null);

            }
            else { 
                OnGameEnd(this, null); 
            }
        }

        #endregion

        #region PrivateMethods

        private void playForDealer()
        {
            OnShowAllCards(this, null);
            Dealer dealer = (Dealer)this.Dealer;
            while (PlayerOne.CurrentHands.Find(v => !v.IsBlackjack || !v.IsBust) != null && (Dealer.CurrentHands.Find(v => v.IsBust) == null) && Dealer.ActiveHand.CurrentScore <= 16)
            {
                var card = Shoe.NextCard;
                dealer.ActiveHand.ReceiveCard(card, false);
            }
        }

        private void calculateScore()
        {
            var dealerScore = Dealer.ActiveHand.CurrentScore;
            foreach (PlayerHand i in PlayerOne.CurrentHands)
            {
                if (!i.IsBust && !i.IsBlackjack)
                {
                    if (i.CurrentScore > dealerScore)
                    {
                        i.WinHand();
                        ((DealerHand)Dealer.ActiveHand).LoseHand();
                        
                    }
                    else if (i.CurrentScore == dealerScore)
                    {
                        i.PushHand();
                        ((DealerHand)Dealer.ActiveHand).PushHand();
                    }
                    else
                    {
                        i.LoseHand();
                        ((DealerHand)Dealer.ActiveHand).WinHand();
                    }
                }
            }
        }

        #endregion

    }
}
