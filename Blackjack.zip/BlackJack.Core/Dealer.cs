﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack.Core
{
    public sealed class Dealer : IPlayer
    {
        private List<IHand> currentHands;

        public string Name { get; set; }

        public Dealer() {
            this.currentHands = new List<IHand>();
   
        }

        public List<IHand> CurrentHands
        {
            get
            {
                return currentHands;
            }
            set
            {
                currentHands = value;
            }
        }

        public IHand ActiveHand
        {
            get
            {
                return CurrentHands[0];
            }
        }

        public int Position
        {

            get
            {
                return 0;
            }
        }
    
    }
}
