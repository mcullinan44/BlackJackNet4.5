﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack.Core
{
    public class PlayerHand : Hand
    {
        public event OnWinHand onWinHand;
        public event OnLoseHand onLoseHand;
        public event OnPushHand onPushHand;

        public PlayerHand(IPlayer player, GameController gameController)
            : base(player, gameController)
        {
            this.onBlackjack += PlayerHand_onBlackjack;
            this.onBust += PlayerHand_onBust;
            this.controller = gameController;
        }

        void PlayerHand_onBust(object sender, OnCardReceivedEventArgs args)
        {
            base.Result = Result.Bust;
            controller.ActivateNextHand();
        }

        void PlayerHand_onBlackjack(object sender, OnCardReceivedEventArgs args)
        {
            controller.PlayerbankRoll += this.CurrentBet.Amount * 2.5;
            if (!controller.Dealer.ActiveHand.IsBlackjack)
                base.Result = Result.Blackjack;

            controller.ActivateNextHand();
        }

        public void PushHand()
        {
            controller.PlayerbankRoll += this.CurrentBet.Amount;
            base.Result = Result.Push;
            onPushHand(this);
        }

        public void WinHand()
        {
            controller.PlayerbankRoll += this.CurrentBet.Amount * 2;
            base.Result = Result.Win;
            onWinHand(this);
        }

        public void LoseHand()
        {
            base.Result = Result.Lost;
            try
            {
                onLoseHand(this);
            }
            catch(Exception ex)
            {

            }
            
        }
    }
}
