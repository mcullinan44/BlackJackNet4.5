﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack.Core
{
    public abstract class Hand : IHand
    {
        protected GameController controller;
        
        public event OnCardReceived onCardReceived;
        public event OnBlackjack onBlackjack;
        public event OnBust onBust;
        public event OnWinHand onWinHand;
        public event OnLoseHand onLoseHand;
        public event OnPushHand onPushHand;

        private readonly List<Card> cardList;
        private Bet currentBet;
        public readonly IPlayer player;
        private Result result;

        public Hand(IPlayer player, GameController controller)
        {
            cardList = new List<Card>();
            this.player = player;
            this.player.CurrentHands.Add(this);
            currentBet = new Bet(this, controller);
            result = new Result();
        }

        public void ReceiveCard(Card card, bool isDeal)
        {
            cardList.Add(card);
            var args = new OnCardReceivedEventArgs(player, this, card);
            if(onCardReceived != null)
                 onCardReceived(this, args);
            var score = this.CurrentScore;
            if (score == 21 && isDeal)
            {
                IsBlackjack = true;
                IsFinalized = true;
                if(onBlackjack != null)
                    onBlackjack(this, args);
            }
            else if (score > 21)
            {
                IsBust = true;
                IsFinalized = true;
                
                if(onBust != null)
                    onBust(this, args);
            }
            Console.WriteLine(string.Format("{0} {1} {2} {3}", card.Value, card.CardSuit, this.CurrentScore, player is Dealer ? "D" : "P"));
        }

        public bool IsFinalized { get; set;  }

        public bool IsBlackjack  { get; set; }

        public bool IsBust { get; set; }

        public List<Card> Cards
        {

            get
            {
                return cardList;
            }
        }

        public Bet CurrentBet
        {
            get
            {
                return currentBet;
            }
            set
            {
                currentBet = value;
            }
        }
        
       public int CardCount
        {
            get
            {
                return cardList.Count;
            }
        }

       public int CurrentScore
       {
           get
           {
               int runningTotal = 0;
               cardList.ForEach((i) =>
               {
                   runningTotal += i.Value;
               });

               if(runningTotal > 21)
               {
                   foreach (var c in cardList)
                   {
                       if (c.CardType == CardType.Ace)
                       {
                           runningTotal -= 10;
                       }

                       if (runningTotal < 21)
                           break;
                   }
               }

               return runningTotal;
           }
       }

       public bool IsActive
       {
           get;
           set; 
       }

        public Result Result
       {

           get { return result; }
           set { result = value; }
       }

       public override string ToString()
       {
           int index = this.player.CurrentHands.IndexOf(this) + 1;

           return "lblHand" + index;
       }


    }
}
