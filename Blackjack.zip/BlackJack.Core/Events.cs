﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack.Core
{
    public delegate void OnCardReceived(object sender, OnCardReceivedEventArgs args);
    public delegate void OnBust(object sender, OnCardReceivedEventArgs args);
    public delegate void OnBlackjack(object sender, OnCardReceivedEventArgs args);
    public delegate void OnWinHand(Hand hand);
    public delegate void OnLoseHand(Hand hand);
    public delegate void OnPushHand(Hand hand);
    public delegate void OnGameEnd();
    public delegate void OnCardRemoved(object sender, OnCardReceivedEventArgs args);
    public delegate void OnBetChanged(object sender, OnBetChangedEventArgs args);

    public class OnCardReceivedEventArgs : EventArgs
    {
        private readonly IPlayer player;
        private readonly Hand hand;
        private readonly Card card;
     
        public OnCardReceivedEventArgs(IPlayer player, Hand hand, Card card)
        {
            this.player = player;
            this.hand = hand;
            this.card = card;
        }

        public IPlayer Player
        {
            get { return player; }
        }

        public Hand Hand
        {
            get { return hand; }
        }

        public Card Card
        {
            get { return card; }
        }
    }


    public class OnBetChangedEventArgs : EventArgs
    {
        public OnBetChangedEventArgs(IHand hand, Bet newBet)
        {
            this.Hand = hand;
            this.NewBet = newBet;
        }

        public IHand Hand { get; private set;}

        public Bet NewBet { get; private set;}
    }
}
